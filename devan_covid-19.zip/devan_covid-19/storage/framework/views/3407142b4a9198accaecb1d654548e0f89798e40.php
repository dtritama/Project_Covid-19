<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Form Covid-19</title>

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <style>
    body {
      background-image: url("<?php echo e(asset('assets/img/bg.jpg')); ?>");
      background-position: center;
      background-size: cover;
      background-repeat: no-repeat;
      background-attachment: fixed;
    }

    .form {
      margin: auto;
      margin: 0 480px;
    }

    .form .card{
      background-color: rgb(255, 255, 255, 0.9);
      margin-top: 160px;
    }

    table {
      margin: 30px 0;
    }

    table tr td {
      padding: 10px 0;
    }
  </style>
</head>
<body>

    <div class="form">
      <div class="card text-left">
        <div class="card-body text-center" style="margin: auto;">
          <h4 class="card-title">Hasil</h4>
          
          <table border="0" class="text-left">
            <tr>
              <td>Nama</td>
              <td style="padding-left: 20px;">
                <input type="text" name="" id="" class="form-control form-control-sm" value="<?php echo e($name); ?>" readonly>
              </td>
            </tr>
            <tr>
              <td>Ya</td>
              <td style="padding-left: 20px;">
                <input type="text" name="" id="" class="form-control form-control-sm" value="<?php echo e($true); ?>" readonly>
              </td>
            </tr>
            <tr>
              <td>Tidak</td>
              <td style="padding-left: 20px;">
                <input type="text" name="" id="" class="form-control form-control-sm" value="<?php echo e($false); ?>" readonly>
              </td>
            </tr>
            <tr>
              <td>Jawaban</td>
              <td style="padding-left: 20px;">
                <input type="text" name="" id="" class="form-control form-control-sm" value="<?php echo e($answer); ?>" readonly>
              </td>
            </tr>
          </table>

          <a href="<?php echo e(url('form')); ?>">Menu Awal</a>

        </div>
      </div>
    </div>

  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH D:\SMKN 1 Cibinong\Ngoding\Projek\form_covid19\resources\views/form/answer.blade.php ENDPATH**/ ?>