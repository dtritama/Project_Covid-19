<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Form Covid-19</title>

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <style>
    body {
      background-image: url("<?php echo e(asset('assets/img/bg.jpg')); ?>");
      background-position: center;
      background-size: cover;
      background-repeat: no-repeat;
      background-attachment: fixed;
    }

    .form .card{
      background-color: rgb(255, 255, 255, 0.9);
    }
  </style>
</head>
<body>

    <div class="form" style="margin-left: 40px;margin-right: 40px;margin-top: 20px;">
      <form action="form/save" method="post">
        <?php echo csrf_field(); ?>
      <div class="card text-left">
        <div class="card-body text-center">
          <h4 class="card-title pt-3 pb-4">Form tentang Covid-19</h4>

          <input type="hidden" name="name" id="" class="form-control form-control-sm" value="<?php echo e($name); ?>">

          <table class="table table-striped">
            <thead>
              <tr class="bg-success text-light">
                <th width="8%">No</th>
                <th width=82%">Pertanyaan</th>
                <th width="10%">Opsi</th>
              </tr>
            </thead>
            <tbody class="">
              
              <tr>
                <td>1</td>
                <td class="text-left">
                  Saya pergi keluar rumah
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question1" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question1" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>2</td>
                <td class="text-left">
                  Saya menggunakan transportasi umum : Online, Angkot, Bus, Taksi, Kereta Api
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question2" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question2" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>3</td>
                <td class="text-left">
                  Saya tidak memakai masker pada saat berkumpul dengan orang lain
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question3" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question3" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>4</td>
                <td class="text-left">
                  Saya berjabat tangan dengan orang lain
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question4" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question4" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>5</td>
                <td class="text-left">
                  Saya tidak membersihkan tangan dengan hand sanitizer / tisu basah sebelum pegang kemudi mobil/motor
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question5" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question5" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>6</td>
                <td class="text-left">
                  Saya menyentuh benda / uang yang juga disentuh orang lain
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question6" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question6" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>7</td>
                <td class="text-left">
                  Saya tidak menjaga jarak 1,5 Meter dengan orang lain ketika : belanja, berkerja , ibadah
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question7" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question7" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>8</td>
                <td class="text-left">
                  Saya makan diluar rumah (warung/restaurant)
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question8" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question8" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>9</td>
                <td class="text-left">
                  Saya tidak minum hangat dan cuci tangan dengan sabun setelah tiba di tujuan
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question9" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question9" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>10</td>
                <td class="text-left">
                  Saya berada di wilayah kelurahan tempat pasien tertular
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question10" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question10" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>11</td>
                <td class="text-left">
                  Saya tidak pasang hand sanitizer di depan pintu masuk, untuk bersihkan tangan sebelum pegang gagang (handle) pintu masuk rumah
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question11" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question11" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>12</td>
                <td class="text-left">
                  Saya tidak mencuci tangan dengan sabun setelah tiba di rumah
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question12" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question12" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>13</td>
                <td class="text-left">
                  Saya tidak menyediakan : tisu basah/atiseptik, masker, sabun antiseptik bagi keluarga di rumah
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question13" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question13" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>14</td>
                <td class="text-left">
                  Saya tidak segera merendam baju dan celana bekas pakai di luar rumah kedalam air panas/sabun
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question14" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question14" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>15</td>
                <td class="text-left">
                  Saya tidak segera mandi keramas setelah saya tiba di rumah
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question15" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question15" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>16</td>
                <td class="text-left">
                  Saya tidak mensosialisasikan check list penilaian resiko pribadi ini kepada keluarga di rumah
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question16" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question16" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>17</td>
                <td class="text-left">
                  Saya dalam sehari tidak kena cahaya matahari minimal 15 menit
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question17" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question17" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>18</td>
                <td class="text-left">
                  Saya tidak jalan kaki / berolahraga minimal 30 menit setiap hari
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question18" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question18" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>19</td>
                <td class="text-left">
                  Saya jarang minum vitamin C dan E, dan kurang tidur
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question19" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question19" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>20</td>
                <td class="text-left">
                  Usia saya diatas 60 tahun
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question20" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question20" value="0"> Tidak
                  </div>
                </td>
              </tr>

              <tr>
                <td>21</td>
                <td class="text-left">
                  Saya mempunyai penyakit : jantung/diabetes/gangguan pernafasan kronik
                </td>
                <td class="text-left">
                  <div>
                    <input type="radio" name="question21" value="1"> Ya
                  </div>
                  <div>
                    <input type="radio" name="question21" value="0"> Tidak
                  </div>
                </td>
              </tr>

            </tbody>
          </table>

          <button type="submit" class="btn btn-success btn-block">Kirim</button>

        </div>
      </div>
      </form>
    </div>

  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH D:\SMKN 1 Cibinong\Ngoding\Projek\form_covid19\resources\views/form/form.blade.php ENDPATH**/ ?>