<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Form;

class FormController extends Controller
{
  public function index() {
    return view('form.index');
  }

  public function form(Request $request) {
    $name = $request->input('name');
    return view('form.form')->with([
      'name' => $name
    ]);
  }

  public function save(Request $request) {
    $true = 0;
    $false = 0;

    $name = $request->input('name');
    $arrayQuestion = [
      $request->input('question1'),
      $request->input('question2'),
      $request->input('question3'),
      $request->input('question4'),
      $request->input('question5'),
      $request->input('question6'),
      $request->input('question7'),
      $request->input('question8'),
      $request->input('question9'),
      $request->input('question10'),
      $request->input('question11'),
      $request->input('question12'),
      $request->input('question13'),
      $request->input('question14'),
      $request->input('question15'),
      $request->input('question16'),
      $request->input('question17'),
      $request->input('question18'),
      $request->input('question19'),
      $request->input('question20'),
      $request->input('question21')
    ];

    foreach ($arrayQuestion as $item) {
      if ($item == 1) {
        $true++;
      }else{
        $false++;
      }
    }

    if ($true >= 7) {
      $answer = "Resiko Tinggi";
    }else{
      $answer = "Resiko Rendah";
    }
    
    $AnswerModel = new Form;
    
    $AnswerModel->name = $name;
    $AnswerModel->true = $true;
    $AnswerModel->false = $false;
    $AnswerModel->answer = $answer;

    $AnswerModel->save();

    return view('form.answer')->with([
      'name' => $name,
      'true' => $true,
      'false' => $false,
      'answer' => $answer
    ]);

  }
}
